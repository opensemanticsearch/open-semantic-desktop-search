#!/usr/bin/env python

from gi.repository import Nautilus, GObject
import urllib
import subprocess
import logging

def indexfile(filename):
	print '/usr/bin/opensemanticsearch_index_dir_zenity ' + filename
        subprocess.call(["/usr/bin/opensemanticsearch_index_dir_zenity", filename])



class SolrIndexExtension(GObject.GObject, Nautilus.MenuProvider):
    def __init__(self):
		logging.basicConfig(filename='/tmp/opensemanticsearch_indexfile-nautilus-debug',level=logging.DEBUG)
    
    def menu_activate_cb(self, menu, files):
        for fileObj in files:
            #Check if file still exists
            if fileObj.is_gone():
                return
            #To handle files with special characters !
            filename = urllib.unquote(fileObj.get_uri())

            #index the file
            indexfile(filename)

        
    def get_file_items(self, window, files):
        if len(files) == 0:
            return

        #For only (local) files
        for fileObj in files:
            if fileObj.get_uri_scheme() != 'file':
                return
            #if fileObj.is_directory() :
            #    return
        item = Nautilus.MenuItem(name='Nautilus::IndexBySolr',
                                 tip='Index with Open Semantic Search engine',
                                 label='Index for search')
        item.connect('activate', self.menu_activate_cb, files)
        return item,
